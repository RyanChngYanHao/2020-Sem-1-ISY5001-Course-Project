### data update ###
### performs dice & slice ###
### output date with close values, return & risk, covariances ###

# setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# get required set from intersecting date range
getSets <- function (){
  # largestMinDate, l 
    individualMinDate <- lapply(reqCols, function(x) min(x$Date))
    l <- max(do.call('c',individualMinDate))
  # smallestMaxDate, s
    individualMaxDate <- lapply(reqCols, function(x) max(x$Date))
    s <- min(do.call('c',individualMaxDate))
  
  # intersectSet
  intersectSet <-  lapply(reqCols, function(x) x[x$Date >= l & x$Date <=s,])
  historical <- lapply(intersectSet, function(x) x$Close)
  historical <- data.frame(do.call('cbind', historical))
  
  # get return, df sorted decreasingly, (a-b)/b
  return <- (historical[2:nrow(historical),] - historical[1:(nrow(historical)-1),])/historical[1:(nrow(historical)-1),]
  
  #4 covariance set
  covSet <- data.frame(cov(return)*252)
  
  #3 calculate annual return
  dailyReturn <- apply(return, 2, mean)
  risk <- apply(return, 2, sd)
  return_risk <- data.frame(Annual_Return = dailyReturn*252, Risk = risk*sqrt(252))
  
  #1 historical
  Date0 <- intersectSet[[1]]$Date
  historical <- data.frame(historical, Date = Date0)
  #2 return
  Date1 <- Date0[1:(length(Date0)-1)]
  return <- data.frame(return, Date = Date1)
  
  list(historical, return, return_risk, covSet)
}

# navigate to and set to data folder, output 2 csv
setwd('..'); setwd('./data')

historical <- getSets()[[1]]
write.csv(historical, file = 'historical.csv', row.names = F)
return <- getSets()[[2]]
write.csv(return, file = 'return.csv', row.names = F)
return_risk <- getSets()[[3]]
write.csv(return_risk, file = 'return_risk.csv')
covSet <- getSets()[[4]]
write.csv(covSet, file = 'covSet.csv')
rm(list = setdiff(ls(),c('reqCols')))
shell.exec(getwd())
### End ###
