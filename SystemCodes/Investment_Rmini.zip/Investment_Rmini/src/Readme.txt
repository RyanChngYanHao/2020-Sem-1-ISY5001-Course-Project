##### Investment_Rmini Readme.txt #####

### Recommended: #######################
- Internet connection (for data download)
- Windows 10
- Microsoft Visual Basic for Applications enabled; Microsoft Excel 
- Microsoft Solver Add-in & library enabled in VBA environment 
- R 3.6.3; packages: forecast; ggplot2; ggpubr & their dependencies

### Setup Steps: #######################
- Please add your location for Rscript.exe in advance setting.
	i.e. C:\Program Files\R\R-3.6.3\bin\Rscript.exe
- Please enable Solver add-in in Microsoft Excel
	i.e. File -> Options -> Add-ins -> select Solver Add-in -> Go.. -> tick Solver Add-in -> OK
- Please tick 'Solver' under References - VBAProject
	i.e. Under MSExcel environment: press Alt+F11, Tools -> References -> tick 'Solver' -> OK

########################################
##### Application is built under #######
- Microsoft Office Professional Plus 2016
- Microsoft Excel Version 2004 (Build 12730.20236)
- Microsoft Visual Basic for Applications
	References - VBAProject
		Visual Basic For Applications
		Microsoft Excel 16.0 Object Library
		OLE Automation
		Microsoft Office 16.0 Object Library
		Microsoft Forms 2.0 Object Library
		Solver
- R version
	platform       x86_64-w64-mingw32          
	arch           x86_64                      
	os             mingw32                     
	system         x86_64, mingw32             
	status                                     
	major          3                           
	minor          6.3                         
	year           2020                        
	month          02                          
	day            29                          
	svn rev        77875                       
	language       R                           
	version.string R version 3.6.3 (2020-02-29)
	nickname       Holding the Windsock

- i.e User may manual install the packages in R if they fail to load:
		install.packages(); package.dependencies()

##### Application built in May 2020 #####
##### Author: Ryan Chng #################