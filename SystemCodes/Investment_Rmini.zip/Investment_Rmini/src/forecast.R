# setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# load packages
reqPackages <- c('forecast', 'ggplot2', 'ggpubr')
for (i in reqPackages){
  if(i %in% rownames(installed.packages()) == F) {install.packages(i)}
  library(i, character.only = T)
}

setwd('..');setwd('./chart')
# get df
for (j in 1:length(reqCols)){
  comment(reqCols[[j]]) <- names(reqCols[j])
  df <- reqCols[[j]]
  
  ### Main Plot
  f = 21                          # 1 by day, 5 by week, 21 by mth
  t <- ts(df$Close, frequency = f) 
  cut_off <- length(t)/f - 1      # fixed last 42 days as training set
  Train <- window(t, end = cut_off-1)
  Test <- window(t, start = cut_off)
  TrainClose <- df$Close[1:(nrow(df)-40)]
  TestClose <- df$Close[(nrow(df)-41):nrow(df)]
  # ETS
    e <- ets(Train)
    eFC <- forecast(e, h = length(Test))
    eFC <- data.frame(eFC, row.names = NULL)
    eFC$Date <- df$Date[(nrow(df)-41):nrow(df)]
    eFC$Model <- rep('ETS')
    eFC <- eFC[,c('Model','Date','Point.Forecast')]
  # HW
    hw <- hw(Train)
    hwFC <- forecast(hw, h = length(Test))
    hwFC <- data.frame(hwFC, row.names = NULL)
    hwFC$Date <- df$Date[(nrow(df)-41):nrow(df)]
    hwFC$Model <- rep('HW')
    hwFC <- hwFC[,c('Model','Date','Point.Forecast')]
  # Linear
    l <- lm(Close ~ Date, data = df[1:(nrow(df)-40),])
    lFC <- data.frame(Model = rep('LM'),
                      Date = df$Date[(nrow(df)-41):nrow(df)],
                      Point.Forecast = predict(l, data.frame(Date = df$Date[(nrow(df)-41):nrow(df)])))
  # Mean
    meanFC <- data.frame(Model = rep('Mean'),
                      Date = df$Date[(nrow(df)-41):nrow(df)],
                      Point.Forecast = mean(TrainClose))
  # Median
    medianFC <- data.frame(Model = rep('Median'),
                         Date = df$Date[(nrow(df)-41):nrow(df)],
                         Point.Forecast = median(TrainClose))
  # base
    allFC <- rbind(eFC,hwFC,lFC, meanFC, medianFC)
    g1 <- ggplot() + geom_line(data = df, aes(x = Date, y = Close))
    g1 <- g1 + geom_line(data = allFC, aes(x = Date, y = Point.Forecast, color = Model), size = 1)
    g1 <- g1 + theme(panel.background = element_rect(fill = "lightblue", 
                                                     colour = "lightblue", 
                                                     size = 0.5, linetype = "solid"),
                     panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                                     colour = "white"), 
                     panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                                     colour = "white"))
    main <- paste(comment(df), '--',
          format(min(df$Date), '%b %Y'), 'to', format(max(df$Date), '%b %Y'))
    g1 <- g1 + ggtitle(main)
        
        
  ### Score
  # MAE & RMSE
  getAccScore <- function() {
    Model <- c('ETS', 'HW', 'LM', 'Mean', 'Median')
    getMAE <- function (){
      MAE1 <- mean(abs(Test-eFC$Point.Forecast))
      MAE2 <- mean(abs(Test-hwFC$Point.Forecast))
      MAE3 <- mean(abs(TestClose-lFC$Point.Forecast))
      MAE4 <- mean(abs(TestClose-mean(TrainClose)))
      MAE5 <- mean(abs(TestClose-median(TrainClose)))
      c(MAE1,MAE2,MAE3,MAE4,MAE5)
    }
    ifelse(eFC$Point.Forecast == mean(eFC$Point.Forecast),
           ePt.Est <- signif(mean(eFC$Point.Forecast),3),
           ePt.Est <- '')
    ifelse(lFC$Point.Forecast == mean(lFC$Point.Forecast),
            lPt.Est <- signif(mean(lFC$Point.Forecast),3),
              lPt.Est <- '')
    
    Pt.Est <- c(ePt.Est,'',lPt.Est,signif(mean(TrainClose),3), signif(median(TrainClose),3))
    MAE <- getMAE()
    getRMSE <- function(){
      RMSE1 <- sqrt(mean((Test-eFC$Point.Forecast)^2))
      RMSE2 <- sqrt(mean((Test-hwFC$Point.Forecast)^2))
      RMSE3 <- sqrt(mean((TestClose-lFC$Point.Forecast)^2))
      RMSE4 <- sqrt(mean((TestClose-mean(TrainClose))^2))
      RMSE5 <- sqrt(mean((TestClose-median(TrainClose))^2))
      c(RMSE1,RMSE2,RMSE3,RMSE4,RMSE5)
    }
    RMSE <- getRMSE()
    data.frame('Test_Set'= Model, 'Pt.Est'= Pt.Est,
               'MAE' = signif(MAE,3), 'RMSE' = signif(RMSE,3))
  }
  aScore <- ggtexttable(getAccScore(), rows = NULL, theme = ttheme("mOrange"))
  
  ### Boxplot
  g2 <- ggplot(df, aes(x = 'Date', y = Close)) + geom_boxplot(width=0.2)
  g2 <- g2 + theme(panel.background = element_rect(fill = 'lightblue', 
                                                        colour = 'lightblue', 
                                                        size = 0.5, linetype = 'solid'),
                    panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                                        colour = "white"), 
                    panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                                        colour = "white"))
  
  ### Quantile
  tmp <- data.frame(Value = quantile(df$Close))
  Quantile <- data.frame(Q = row.names(tmp), Value = signif(tmp$Value,3))
  Quantile <- Quantile[order(row.names(Quantile), decreasing = T),]
  meanRow <- data.frame(Q = '<Mean>', Value = signif(mean(df$Close),3))
  Quantile <- rbind(Quantile, meanRow)
  Quantile <- ggtexttable(Quantile, rows = NULL, theme = ttheme("mBlue"))
  
  ### Past Table
  getRow <- function(d){
    n <- nrow(df)
    if (n>d){
      Return <- (df[2:n,]$Close - df[1:(n-1),]$Close) / df[1:(n-1),]$Close
      
      row <- paste0('<',d,'d>')
      med_mean <- paste0(signif(median(df$Close[(n-d+1):n]),3),
                         ';',
                         signif(mean(df$Close[(n-d+1):n]),3))
      return <- mean(Return[(n-d+1):n], na.rm = T)*252
      std <- sd(Return[(n-d+1):n], na.rm = T)*sqrt(252)
      c(row, med_mean, return, std)
    }
  }
  r50 <- getRow(50)
  r100 <- getRow(100)
  r252 <- getRow(252)
  r504 <- getRow(504)
  pastTbl <- data.frame(rbind(r50,r100,r252,r504), row.names = NULL, stringsAsFactors = F)
  names(pastTbl) <- c('Past','Med;Ave','Return','Risk')
  pastTbl$Return <- paste0(signif(as.numeric(pastTbl$Return),3)*100,'%')
  pastTbl$Risk <- paste0(signif(as.numeric(pastTbl$Risk),3)*100,'%')
  pastTbl <- ggtexttable(pastTbl, rows = NULL, theme = ttheme("mOrange"))
    
  ### export to pdf
  pdfName <- paste0(comment(df), '.pdf')
  bottomRight <- ggarrange(g2, Quantile, ncol = 2, nrow = 1)
  bottomLeft <- ggarrange(pastTbl, aScore, ncol = 1, nrow = 2)
  bottom <- ggarrange(bottomLeft, bottomRight, ncol = 2, nrow = 1)
  plotlist <- ggarrange(g1, bottom, nrow = 2, ncol = 1)
  ggexport(plotlist , filename = pdfName)
    
}
rm(list = setdiff(ls(),c('reqCols')))
shell.exec(getwd())
