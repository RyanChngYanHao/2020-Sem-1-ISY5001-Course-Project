# pass argument 1 or 2 or 3
args = commandArgs(trailingOnly=TRUE)

# set directory #
# Daniel E, Cook
# https://www.danielecook.com/setting-the-working-directory-in-r/
getScriptPath <- function(){
  cmd.args <- commandArgs()
  m <- regexpr("(?<=^--file=).+", cmd.args, perl=TRUE)
  script.dir <- dirname(regmatches(cmd.args, m))
  if(length(script.dir) == 0) stop("can't determine script dir: please call the script with Rscript")
  if(length(script.dir) > 1) stop("can't determine script dir: more than one '--file' argument detected")
  return(script.dir)
}
setwd(getScriptPath())
setwd('..'); setwd('./csv')

# data prep
getReqCols <- function(){
  fullSet <- lapply(list.files(pattern = '*.csv'), read.csv, stringsAsFactor = F)
  names(fullSet) <- gsub('.csv','', list.files(pattern = '*.csv'))
  reqCols <- lapply(fullSet, function(x) data.frame(Date = as.Date(x$Date), Close = as.numeric(x$Close)))
  reqCols <- lapply(reqCols, na.omit)
  lapply(reqCols, function(x) x[order(x$Date),])
}
reqCols <- getReqCols()

if (args == 1) {
  setwd('..'); setwd('./src')
  source('allot.R')
  setwd('..'); setwd('./src')
  source('forecast.R')
} else if (args == 2) {
  setwd('..'); setwd('./src')
  source('forecast.R')
} else if (args == 3) {
  setwd('..'); setwd('./src')
  source('allot.R')
} else {
  print('Invalid arg called!')
}

  
  
  